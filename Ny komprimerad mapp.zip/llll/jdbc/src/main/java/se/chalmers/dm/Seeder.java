package se.chalmers.dm;

import com.github.javafaker.Address;
import com.github.javafaker.Bool;
import com.github.javafaker.ChuckNorris;
import com.github.javafaker.Faker;

import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Random;

public class Seeder {
    private Faker faker;
    private Random random;
    private Connection connection;

    public Seeder(Faker faker, Connection connection, Random random){
        this.faker=faker;
        this.random=random;
        this.connection=connection;

    }

    public static void createWebPageTable(){


        QueryHelper qh = new QueryHelper();

        qh.sqlQuery("create_webpage_table.sql");

    }

    public static void insertFakeUsersWithWebPage(int n) throws MalformedURLException, SQLException {
        Faker faker = new Faker();
        int id = 0;

        QueryHelper qh = new QueryHelper();
        for(int i = 0; i < n; i++){
        int author = 0;


            ChuckNorris content = faker.chuckNorris();

            double randNumber = Math.random();
            int d = (int) (randNumber * 100);
            int popularity = (int)d + 1;

            URL myURL = new URL("http://example.com/");

            qh.sqlQuery("insert_webpage.sql");

            id++;
        }

    }

    public static void createUserTable() {

        QueryHelper qh = new QueryHelper();

        qh.sqlQuery("insert_user.sql");


    }


    public void insertFakeUsers(int n) throws SQLException {

        Faker faker = new Faker();

        int ID = 0;

        QueryHelper qh = new QueryHelper();

        for(int i = 0; i < n; i++){

            String FName = faker.name().firstName();
            String LName = faker.name().lastName();
            String Ssn = faker.idNumber().ssnValid();
            String Email = FName+LName+"@gmail.com";
            Bool isActive = faker.bool();

            qh.sqlQuery("create_user_table.sql");

            ID++;


        }

    }

}

