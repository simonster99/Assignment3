package se.chalmers.dm;

import java.net.URL;

    public class WebPage {

            private int popularity ;
            private int id;
            private int author;
            private String content;
            private String myURL;

            public WebPage(int popularity, int id, int author, String content, String myURL){

                this.popularity = popularity;
                this.id = id;
                this.author = author;
                this.content = content;
                this.myURL = myURL;
            }
}
