package se.chalmers.dm;

import java.sql.*;

public class JDBCTestDriver {
    // DB connection configuration
    private static String DRIVER_CLASS = "org.postgresql.Driver";
    private static String DB_USER = "postgres";
    private static String DB_PASSWORD = "";
    private static String DB_URL = "jdbc:postgresql://localhost:5432/websitedb";
    private static int EXIT_FAILURE = 1;

    public static void main(String[] args) {
        Connection c = null;
        PreparedStatement stmt = null;
        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/websitedb",
                            "postgres", "");

            stmt = c.prepareStatement("SELECT 15 AS retval;");
            ResultSet rs = stmt.executeQuery();
            while ( rs.next() ) {
                System.out.print(rs.getString("retval"));
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println("Error "+ e.getMessage());
            System.exit(0);
        }
    }
}