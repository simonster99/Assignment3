package se.chalmers.dm;

import com.github.javafaker.Faker;

import java.net.MalformedURLException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Random;

public class SeederTestDriver {
    // IMPORTANT: Do NOT change this code, just uncomment it!
    public static void main(String[] args) throws SQLException, MalformedURLException {
         Faker faker = new Faker();
         Connection connection = ConnectionHelper.createPostgresConnection();
         Random random = new Random();
         Seeder seeder = new Seeder(faker, connection, random);
         System.out.println("Creating user table");
         Seeder.createUserTable();
         System.out.println("Inserting fake users");
         seeder.insertFakeUsers(12);
         System.out.println("Creating web page table");
         Seeder.createWebPageTable();
         System.out.println("Inserting fake users with webpage");
         Seeder.insertFakeUsersWithWebPage(200);
    }
}
